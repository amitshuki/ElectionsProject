#pragma once
class VotingRound
{

};

